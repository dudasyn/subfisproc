-- SCRIPT DE ATUALIZAÇÃO SUBFISPROC - EXECUTE NO PHPMYADMIN (HOSTINGER)
-- Copie estes comandos e rode na aba SQL do banco de dados na Hostinger.

-- 1. Tabela de Setores: Adicionar campo is_internal
ALTER TABLE sectors ADD COLUMN IF NOT EXISTS is_internal BOOLEAN DEFAULT TRUE;

-- 2. Tabela de Movimentações: Adicionar campo responsible_id
ALTER TABLE movements ADD COLUMN IF NOT EXISTS responsible_id INT AFTER destination_sector_id;

-- 3. Adicionar a Foreign Key para o Auditor Responsável (se não existir)
-- Nota: O MySQL/MariaDB às vezes falha se já houver FK, mas você pode rodar esse bloco com segurança.
ALTER TABLE movements ADD CONSTRAINT fk_movement_responsible 
FOREIGN KEY (responsible_id) REFERENCES responsibles(id);

-- Opcional: Se sua tabela movements ainda tinha a coluna 'responsible' antiga (como texto), 
-- você pode mantê-la ou rodar o comando abaixo para limpar dps de garantir o backup.
-- ALTER TABLE movements DROP COLUMN IF EXISTS responsible;
